package controller;

import dao.CustomerDAO;
import model.Customer;
import view.CustomerView;
import exception.DatabaseException;

import java.util.List;

public class CustomerController {
    private CustomerDAO customerDAO;
    private CustomerView customerView;

    public CustomerController(CustomerDAO customerDAO, CustomerView customerView) {
        this.customerDAO = customerDAO;
        this.customerView = customerView;
    }

    // Add a new customer
    public void addCustomer(Customer customer) {
        try {
            customerDAO.addCustomer(customer);
            customerView.displayMessage("Customer added successfully!");
        } catch (DatabaseException e) {
            customerView.displayMessage(e.getMessage());
        }
    }

    // View all customers
    public void viewCustomers() {
        try {
            List<Customer> customers = customerDAO.getCustomers();
            customerView.displayCustomers(customers);
        } catch (DatabaseException e) {
            customerView.displayMessage(e.getMessage());
        }
    }

    // Update customer
    public void updateCustomer() {
        try {
            int customerId = customerView.getCustomerId();
            Customer updatedCustomer = customerView.getUpdatedCustomerDetails(customerId);
            customerDAO.updateCustomer(updatedCustomer);
            customerView.displayMessage("Customer updated successfully!");
        } catch (DatabaseException e) {
            customerView.displayMessage(e.getMessage());
        }
    }

    // Delete customer
    public void deleteCustomer() {
        try {
            int customerId = customerView.getCustomerId();
            customerDAO.deleteCustomer(customerId);
            customerView.displayMessage("Customer deleted successfully!");
        } catch (DatabaseException e) {
            customerView.displayMessage(e.getMessage());
        }
    }
}
