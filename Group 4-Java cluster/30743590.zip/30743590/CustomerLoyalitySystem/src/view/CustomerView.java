package view;

import model.Customer;

import java.util.List;
import java.util.Scanner;

public class CustomerView {
    private Scanner scanner = new Scanner(System.in);

    // Display message
    public void displayMessage(String message) {
        System.out.println(message);
    }

    // Display customers
    public void displayCustomers(List<Customer> customers) {
        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }

    // Get customer information from user (for add and update)
    public Customer getCustomerDetails() {
        System.out.println("Enter customer name:");
        String name = scanner.nextLine();
        System.out.println("Enter customer email:");
        String email = scanner.nextLine();
        System.out.println("Enter customer phone:");
        String phone = scanner.nextLine();
        System.out.println("Enter total points:");
        int totalPoints = Integer.parseInt(scanner.nextLine());
        return new Customer(name, email, phone, totalPoints);
    }

    // Get customer ID for update/delete operations
    public int getCustomerId() {
        System.out.println("Enter customer ID:");
        return Integer.parseInt(scanner.nextLine());
    }

    // Get updated customer information from user
    public Customer getUpdatedCustomerDetails(int customerId) {
        Customer customer = getCustomerDetails();
        customer.setCustomerId(customerId);
        return customer;
    }
}
