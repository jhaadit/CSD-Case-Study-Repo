/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

public class Purchase {
    private int purchaseId;
    private int customerId;
    private int rewardId;
    private Date purchaseDate;
    private int pointsEarned;

    public Purchase(int customerId, int rewardId, Date purchaseDate, int pointsEarned) {
        this.customerId = customerId;
        this.rewardId = rewardId;
        this.purchaseDate = purchaseDate;
        this.pointsEarned = pointsEarned;
    }

    // Getters and Setters
    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getRewardId() {
        return rewardId;
    }

    public void setRewardId(int rewardId) {
        this.rewardId = rewardId;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public int getPointsEarned() {
        return pointsEarned;
    }

    public void setPointsEarned(int pointsEarned) {
        this.pointsEarned = pointsEarned;
    }

    @Override
    public String toString() {
        return "Purchase{" +
                "purchaseId=" + purchaseId +
                ", customerId=" + customerId +
                ", rewardId=" + rewardId +
                ", purchaseDate=" + purchaseDate +
                ", pointsEarned=" + pointsEarned +
                '}';
    }
}
