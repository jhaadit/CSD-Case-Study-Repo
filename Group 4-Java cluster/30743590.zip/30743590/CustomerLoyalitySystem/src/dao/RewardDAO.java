/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Reward;
import exception.DatabaseException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RewardDAO {
    private Connection conn;

    public RewardDAO(Connection conn) {
        this.conn = conn;
    }

    public void addReward(Reward reward) throws DatabaseException {
        String query = "INSERT INTO Reward (name, points_required, description) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, reward.getName());
            stmt.setInt(2, reward.getPointsRequired());
            stmt.setString(3, reward.getDescription());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add reward: " + e.getMessage());
        }
    }

    public List<Reward> getRewards() throws DatabaseException {
        List<Reward> rewards = new ArrayList<>();
        String query = "SELECT * FROM Reward";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Reward reward = new Reward(
                    rs.getString("name"),
                    rs.getInt("points_required"),
                    rs.getString("description")
                );
                reward.setRewardId(rs.getInt("reward_id"));
                rewards.add(reward);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to fetch rewards: " + e.getMessage());
        }
        return rewards;
    }

    // Implement methods for update and delete
}
