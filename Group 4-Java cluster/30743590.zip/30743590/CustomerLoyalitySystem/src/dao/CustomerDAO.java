/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Customer;
import exception.DatabaseException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
    private Connection conn;

    public CustomerDAO(Connection conn) {
        this.conn = conn;
    }

    public void addCustomer(Customer customer) throws DatabaseException {
        String query = "INSERT INTO Customer (name, email, phone, total_points) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPhone());
            stmt.setInt(4, customer.getTotalPoints());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add customer: " + e.getMessage());
        }
    }

    public List<Customer> getCustomers() throws DatabaseException {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Customer customer = new Customer(
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getInt("total_points")
                );
                customer.setCustomerId(rs.getInt("customer_id"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to fetch customers: " + e.getMessage());
        }
        return customers;
    }

    // Implement methods for update and delete
    public void updateCustomer(Customer customer) throws DatabaseException {
        String query = "UPDATE Customer SET name = ?, email = ?, phone = ?, total_points = ? WHERE customer_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPhone());
            stmt.setInt(4, customer.getTotalPoints());
            stmt.setInt(5, customer.getCustomerId());
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated == 0) {
                throw new DatabaseException("Customer not found.");
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update customer: " + e.getMessage());
        }
    }
    
    public void deleteCustomer(int customerId) throws DatabaseException {
        String query = "DELETE FROM Customer WHERE customer_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted == 0) {
                throw new DatabaseException("Customer not found.");
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete customer: " + e.getMessage());
        }
    }
    
}
