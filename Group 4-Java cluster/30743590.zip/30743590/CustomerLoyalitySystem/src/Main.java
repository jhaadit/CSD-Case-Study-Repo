public class Main {

    public static void main(String[] args) {
        System.out.println("Application started successfully!");

        // Set up the JDBC connection and handle the program's logic
        String jdbcURL = "jdbc:mysql://localhost:3306/loyalty_program";
        String username = "root";  // Use your MySQL username
        String password = "password";  // Use your MySQL password

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            Connection conn = DriverManager.getConnection(jdbcURL, username, password);

            // Initialize DAOs, Views, and Controllers
            CustomerDAO customerDAO = new CustomerDAO(conn);
            CustomerView customerView = new CustomerView();
            CustomerController customerController = new CustomerController(customerDAO, customerView);

            // Set up a basic menu to interact with the system
            Scanner scanner = new Scanner(System.in);
            int choice;

            do {
                System.out.println("1. Add Customer");
                System.out.println("2. View Customers");
                System.out.println("3. Update Customer");
                System.out.println("4. Delete Customer");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                
                try {
                    choice = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input! Please enter a number.");
                    continue;
                }

                switch (choice) {
                    case 1:
                        Customer newCustomer = customerView.getCustomerDetails();
                        customerController.addCustomer(newCustomer);
                        break;
                    case 2:
                        customerController.viewCustomers();
                        break;
                    case 3:
                        customerController.updateCustomer();
                        break;
                    case 4:
                        customerController.deleteCustomer();
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice! Please choose again.");
                }

            } while (choice != 5);

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
        }
    }
}
